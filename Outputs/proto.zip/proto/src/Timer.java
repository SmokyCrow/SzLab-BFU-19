public class Timer {

    private Game game;

    public void tick(){

    }
}
